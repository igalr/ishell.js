#!/bin/bash

# Upload files listed under "# to store" in .gitignore to S3
# Usage: ./store.sh [s3-bucket-name]

BUCKET="redleaf-backup"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
GITIGNORE="$SCRIPT_DIR/.gitignore"
REPO_NAME="$(basename "$(git -C "$SCRIPT_DIR" rev-parse --show-toplevel)")"
S3_PREFIX="secrets/$REPO_NAME"
PROFILE="redleaf"

if [[ ! -f "$GITIGNORE" ]]; then
  echo "Error: .gitignore not found at $GITIGNORE"
  exit 1
fi

# Extract files under "# to store" section (stop at next comment or blank line ending the section)
in_section=false
files=()

while IFS= read -r line; do
  if [[ "$line" == "# to store" ]]; then
    in_section=true
    continue
  fi
  if $in_section; then
    # Stop at next comment section
    if [[ "$line" == "#"* ]]; then
      break
    fi
    # Skip blank lines
    [[ -z "$line" ]] && continue
    files+=("$line")
  fi
done < "$GITIGNORE"

if [[ ${#files[@]} -eq 0 ]]; then
  echo "No files found under '# to store' in .gitignore"
  exit 1
fi

echo "Uploading to s3://$BUCKET/$S3_PREFIX/"
echo ""

include_args=()
for file in "${files[@]}"; do
  include_args+=(--include "$file")
done

aws s3 sync "$SCRIPT_DIR" "s3://$BUCKET/$S3_PREFIX/" \
  --exclude "*" "${include_args[@]}" \
  --profile "$PROFILE"

echo ""
echo "Done"
